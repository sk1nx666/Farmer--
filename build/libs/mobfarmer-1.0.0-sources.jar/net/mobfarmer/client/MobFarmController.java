package net.mobfarmer.client;

import baritone.api.BaritoneAPI;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2183.class_2184;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9334;

public final class MobFarmController {
	private MobFarmController() {}

	/** When non-null, we keep killing this entity type until /farmer stop. */
	private static net.minecraft.class_1299<?> huntType;

	private static UUID targetId;
	private static Boolean allowBreakBefore;

	public static void start(class_1657 player, String mobArg, Consumer<String> onMessage) {
		abortSessionSilently();
		var type = resolveEntityType(mobArg);
		if (type == null) {
			onMessage.accept("Unknown mob: " + mobArg + " (try minecraft:zombie, creeper, ...).");
			return;
		}
		class_1309 nearest = findNearest(player, type, null);
		if (nearest == null) {
			onMessage.accept("No " + type.method_5897().getString() + " found nearby.");
			return;
		}
		allowBreakBefore = BaritoneAPI.getSettings().allowBreak.value;
		BaritoneAPI.getSettings().allowBreak.value = false;

		huntType = type;
		targetId = nearest.method_5667();
		refreshFollow();
		onMessage.accept("Farming " + type.method_5897().getString() + " — use /farmer stop to cancel.");
	}

	public static void stop(Consumer<String> onMessage) {
		boolean hadSession = huntType != null;
		abortSessionSilently();
		if (hadSession) {
			onMessage.accept("Mob farming stopped.");
		}
	}

	private static void abortSessionSilently() {
		restoreBaritoneBreakSetting();
		huntType = null;
		targetId = null;
		try {
			BaritoneAPI.getProvider().getPrimaryBaritone().getFollowProcess().cancel();
		} catch (Throwable ignored) {
		}
	}

	public static void tick(class_310 mc) {
		if (huntType == null || mc.field_1724 == null || mc.field_1687 == null) {
			return;
		}
		class_1657 player = mc.field_1724;
		class_1309 living = resolveHuntTarget(mc, player);
		if (living == null) {
			return;
		}

		double reach = player.method_45325(class_5134.field_47759);
		if (player.method_5739(living) <= reach + 0.25) {
			int slot = bestWeaponHotbarSlot(player);
			if (slot >= 0 && slot != player.method_31548().method_67532()) {
				player.method_31548().method_61496(slot);
			}
			player.method_5702(class_2184.field_9851, living.method_5836(1f));
			if (mc.field_1761 != null && player.method_7261(0f) >= 0.92f) {
				mc.field_1761.method_2918(player, living);
				player.method_6104(class_1268.field_5808);
			}
		}
	}

	private static class_1309 resolveHuntTarget(class_310 mc, class_1657 player) {
		class_1309 cur = null;
		if (targetId != null) {
			class_1297 e = mc.field_1687.method_66347(targetId);
			if (e instanceof class_1309 le && le.method_5805()) {
				cur = le;
			}
		}
		if (cur == null) {
			acquireNextTarget(player);
			if (targetId != null) {
				class_1297 e = mc.field_1687.method_66347(targetId);
				if (e instanceof class_1309 le && le.method_5805()) {
					cur = le;
				}
			}
		}
		return cur;
	}

	private static void restoreBaritoneBreakSetting() {
		if (allowBreakBefore != null) {
			BaritoneAPI.getSettings().allowBreak.value = allowBreakBefore;
			allowBreakBefore = null;
		}
	}

	private static void refreshFollow() {
		if (targetId == null) {
			return;
		}
		UUID id = targetId;
		BaritoneAPI.getProvider().getPrimaryBaritone().getFollowProcess().follow(e -> e.method_5805() && e.method_5667().equals(id));
	}

	private static void acquireNextTarget(class_1657 player) {
		if (huntType == null) {
			return;
		}
		class_1309 next = findNearest(player, huntType, targetId);
		if (next == null) {
			targetId = null;
			try {
				BaritoneAPI.getProvider().getPrimaryBaritone().getFollowProcess().cancel();
			} catch (Throwable ignored) {
			}
			return;
		}
		targetId = next.method_5667();
		refreshFollow();
	}

	private static class_1309 findNearest(class_1657 player, net.minecraft.class_1299<?> type, UUID exclude) {
		class_238 box = player.method_5829().method_1014(192.0);
		var nearby = player.method_73183().method_8390(class_1309.class, box, e -> e != player && e.method_5805() && e.method_5864() == type && (exclude == null || !e.method_5667().equals(exclude)));
		class_1309 best = null;
		double bestD = Double.MAX_VALUE;
		for (class_1309 candidate : nearby) {
			double d = candidate.method_5858(player);
			if (d < bestD) {
				bestD = d;
				best = candidate;
			}
		}
		return best;
	}

	private static net.minecraft.class_1299<?> resolveEntityType(String raw) {
		String s = raw.trim();
		if (!s.contains(":")) {
			s = "minecraft:" + s;
		}
		class_2960 id = class_2960.method_12829(s);
		if (id == null) {
			return null;
		}
		return class_7923.field_41177.method_10223(id).map(net.minecraft.class_6880::comp_349).orElse(null);
	}

	private static int bestWeaponHotbarSlot(class_1657 player) {
		boolean hasSword = false;
		for (int i = 0; i < 9; i++) {
			class_1799 s = player.method_31548().method_5438(i);
			if (!s.method_7960() && s.method_31573(class_3489.field_42611)) {
				hasSword = true;
				break;
			}
		}

		int best = -1;
		float bestScore = -1f;
		for (int i = 0; i < 9; i++) {
			class_1799 stack = player.method_31548().method_5438(i);
			if (stack.method_7960()) {
				continue;
			}
			if (hasSword && stack.method_31573(class_3489.field_42612)) {
				continue;
			}
			float score = baseAttackDamage(stack);
			if (score > bestScore) {
				bestScore = score;
				best = i;
			}
		}
		return best;
	}

	private static float baseAttackDamage(class_1799 stack) {
		class_9285 mods = stack.method_58695(class_9334.field_49636, class_9285.field_49326);
		float sum = 0f;
		for (class_9285.class_9287 e : mods.comp_2393()) {
			if (e.comp_2395().method_55838(class_5134.field_23721)) {
				sum += (float) e.comp_2396().comp_2449();
			}
		}
		if (sum <= 0f) {
			return 0.25f;
		}
		return sum;
	}
}
